ASVZ BOT

Currently only working on windows. 

1: 	run install.bat, make sure you have python installed in this directory

2: 	Adjust settings.txt for your ETH Login credentials

3: 	Execute ASVZBot.bat and have fun! :)
